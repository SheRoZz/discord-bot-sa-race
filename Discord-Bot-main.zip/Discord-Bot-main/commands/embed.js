const Discord = require('discord.js')

module.exports = {
    run: message => {
        message.channel.send(new Discord.MessageEmbed()
            .setTitle('Mon titre')
            .setTitle('DU CUL BORDEEEEEL')
            .setDescription('[PORNHUB](https://pornhub.com) **LE CUUUUUL**')
            .setColor('RANDOM')
            .addField('Champ 1 **bonjour**', 'LE FIAK', true)
            .addField('Champ 2', 'Blabla', true)
            .setAuthor('ZENKO **bonjour**', 'https://cdn.discordapp.com/attachments/718476721418141728/719563110154764298/logo.png', 'https://pornhub.com')
            .setImage('https://cdn.discordapp.com/attachments/352952392855322625/802274150974357564/20201109_132347.jpg')
            .setThumbnail('https://cdn.discordapp.com/attachments/352952392855322625/802274235686715412/4232_thicc_smirk.png')
            .setFooter('sérieux moi j\'adore le cul', 'https://cdn.discordapp.com/attachments/352952392855322625/802274150974357564/20201109_132347.jpg')
            .setTimestamp()
            .setURL('https://pornhub.com'))
    },
    name: 'embed',
    help: {
        description: 'Crée un message Embed',
        syntax: '<VOIR CODE SOURCE POUR ÉDITER LE MESSAGE>'
    }
}